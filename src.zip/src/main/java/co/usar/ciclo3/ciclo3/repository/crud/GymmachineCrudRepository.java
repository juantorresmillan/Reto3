package co.usar.ciclo3.ciclo3.repository.crud;

import co.usar.ciclo3.ciclo3.model.Gymmachine;
import org.springframework.data.repository.CrudRepository;

public interface GymmachineCrudRepository extends CrudRepository<Gymmachine, Integer> {
}
